---
title: Dead Sea Scrolls
type: Primary-Source
author(s):
- '[[Essenes]]'
date_written: null
periods: []
religious-tradition:
- Judaism
- '[[Apocalyptic Jews]]'
source_type: Text
aliases:
- Dead Sea Scrolls
tags:
- Primary-Source
linter-yaml-title-alias: Dead Sea Scrolls
date_created: Wednesday, July 2nd 2025, 10:42:45 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
---

# Dead Sea Scrolls


## Source Overview
Discovered in 1947, written by the [[Essenes]] who were [[Apocalyptic Jews]]

## Key Themes or Passages
-  
-  
-  

## Text Context
<Information about where this text was written, its purpose, or audience >

## My Notes
- < Your detailed notes or excerpts go here >
