---
date_created: Thursday, July 3rd 2025, 9:10:44 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
title: New Testament
aliases:
- New Testament
tags:
- Topic
linter-yaml-title-alias: New Testament
periods: null
religious-tradition: null
---
# New Testament
