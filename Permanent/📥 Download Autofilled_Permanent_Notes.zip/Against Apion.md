---
title: Against Apion
type: Primary-Source
author(s):
- '[[Josephus]]'
date_written: null
periods:
- Second-Temple-Period
religious-tradition:
- Second-Temple-Judaism
source_type: Text
aliases:
- Untitled
tags:
- Primary-Source
linter-yaml-title-alias: Against Apion
date_created: Wednesday, July 2nd 2025, 10:50:39 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
---

# Untitled

## Source Overview
< Add a brief description of the source and its historical context >

## Key Themes or Passages
-  
-  
-  

## Text Context
<Information about where this text was written, its purpose, or audience >

## My Notes
- < Your detailed notes or excerpts go here >
