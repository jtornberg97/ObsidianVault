---
title: John Calvin
type: Person
birth_date: 1509 CE
death_date: 1564 CE
periods:
- Reformation
religious-tradition:
- Calvinism
- Reformed
- Protestant
- Reformation
role: null
associated_movements:
- Calvinism
- Reformation
notable_works: null
aliases:
- Calvinism
tags:
- Reformation
- Protestant
- Calvinism
- Person
- Reformed
date_created: Wednesday, July 2nd 2025, 10:58:33 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: John Calvin
---

# John Calvin

## Summary
John Calvin is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Contributions
- 
- 
- 

## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[Related person 1]]
- [[Mentor, student, opponent, or contemporary]]

## My Notes
- < Reflections, controversies, connections to your studies >
