---
title: Council of Nicaea
type: Topic
periods:
- Nicence-and-Post-Nicene
religious-tradition:
- Nicene Christianity
- Arianism
tags:
- Arianism
- Topic
- Nicene-Christianity
- Nicene-and-Post-Nicene
date_created: Tuesday, July 1st 2025, 9:34:11 pm
date_modified: Sunday, July 6th 2025, 9:38:09 pm
aliases:
- Council of Nicaea
linter-yaml-title-alias: Council of Nicaea
---

# Council of Nicaea

## Summary

325 CE


## Key Points
- 
- 
- 

## My Notes
- < Key takeaways, reflections, or disagreements >
- 