---
date_created: Tuesday, July 1st 2025, 10:36:13 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
title: Matthew (Disciple)
aliases:
- Matthew (Disciple)
tags:
- Topic
linter-yaml-title-alias: Matthew (Disciple)
periods: null
religious-tradition: null
---
# Matthew (Disciple)
