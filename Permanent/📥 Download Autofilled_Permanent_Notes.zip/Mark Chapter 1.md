---
title: Mark Chapter 1
type: Bible-Verse
book: "[[Mark (Gospel)]]"
chapter: Mark 1
verses: 1-13
testament: "[[New Testament]]"
canonical_order: 
cross_references: 
related_notes: 
aliases:
  - Mark 1.1-8
tags:
  - Verse
  - Scripture
  - Bible-Verse
linter-yaml-title-alias: Mark 1.1-8
date_created: Tuesday, July 1st 2025, 8:26:10 pm
date_modified: Monday, July 7th 2025, 9:40:20 pm
---
Mark 1:1-13

## Literary Features
- Dramatization
## Theological Themes
- [[Repentance]]
- [[Baptism]]
- [[Messiah]]
- [[Apocalyptic Jews|Apocalyptic]]
## Cross References
- [[Exodus]]
- [[Isaiah]]
## Commentary & Interpretation

[[NT Wright]]

1-8:
- [[John the Baptist]] shares news of coming [[Messiah]], [[Apocalyptic Jews]] expected message, but not one calling for repentance
- [[John the Baptist]] is retelling the story of [[Exodus]] but now saying that [[Judaism|Jews]] were to "Leave behind 'Egypt' - the world of sin in which they were living, the world of rebelling against the living God"
- [[John the Baptist]] is preparing the Jewish world for "someone", maybe the [[Messiah]], maybe [[YHWH]] himself
- Goal of this passage is to sense the shock of the new thing God was doing

9-13
- [[John the Baptist]] baptizes [[Jesus]] 

[[Jewish Annotated New Testament]]
- 

## Your Reflections

July 2025
- 
