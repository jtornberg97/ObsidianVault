---
date_created: Wednesday, July 2nd 2025, 9:28:01 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
title: Nevi'im (Former Prophets)
aliases:
- Nevi'im (Former Prophets)
tags:
- Topic
linter-yaml-title-alias: Nevi'im (Former Prophets)
periods: null
religious-tradition: null
---
# Nevi'im (Former Prophets)
