---
title: Jesus
type: Person
birth_date: 4 BCE
death_date: 30 CE
periods:
- Second-Temple-Period
- Apostolic-Period
religious-tradition:
- Early Christianity
role: '[[Messiah]]'
associated_movements: Early Christianity
notable_works:
- '[[Passion]]'
aliases:
- Jesus Christ
- Christ
- Jesus of Nazareth
tags:
- Second-Temple-Period
- Messiah
- Judaism/Second-Temple-Judaism
- Person
- Apocalyptic
date_created: Tuesday, July 1st 2025, 10:30:52 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: Jesus
---

# Jesus

## Summary
Jesus is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Contributions
- 
- 
- 

## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[Related person 1]]
- [[Mentor, student, opponent, or contemporary]]

## My Notes
- < Reflections, controversies, connections to your studies >
