---
title: Monotheism
type: Topic
periods: null
religious-tradition:
- Judaism
tags:
- Topic
- Judaism
date_created: Tuesday, July 1st 2025, 10:32:29 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
aliases:
- Monotheism
linter-yaml-title-alias: Monotheism
---

# Monotheism

## Summary
"There is only one God" - [[Bart Ehrman|Ehrman]]

## Key Points
- Judaism is the first real Monotheistic religion 
- Majority of the [[Roman Empire]] was [[Pagan]]

## My Notes
- < Key takeaways, reflections, or disagreements >
- 