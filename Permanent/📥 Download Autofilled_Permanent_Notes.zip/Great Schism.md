---
title: Great Schism
type: Topic
periods:
- High-Middle-Ages
religious-tradition:
- Roman Catholic
- Eastern Orthodox
aliases:
- East-West Schism
- Schism of 1054
tags:
- Roman-Catholic
- Eastern-Orthodox
- Topic
- High-Middle-Ages
date_created: Tuesday, July 1st 2025, 9:07:03 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: Great Schism
---

# Great Schism

## Summary
Great Schism is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Points
- 
- 
- 

## My Notes
- - Great Schism reflects a broader movement or idea in religious history.
- It shaped beliefs and practices over centuries.
- Modern interpretations vary widely.
- 