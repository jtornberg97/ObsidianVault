---
title: Pliny the Younger
type: Person
birth_date: 61 CE
death_date: 113 CE
periods:
- Early-Roman-Empire
religious-tradition:
- Pagan
role: Governor
associated_movements: null
notable_works: null
aliases:
- Pliny
tags:
- Person
- Early-Roman-Empire
- Pagan
date_created: Tuesday, July 1st 2025, 10:33:41 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: Pliny the Younger
---

# Pliny the Younger

## Summary
Pliny the Younger is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Contributions
- Wrote a letter to the Emperor [[Trajan]] about the problem, called them "Christians" because they were worshipping [[Jesus]]
	- First mention to [[Jesus|Jesus]] in a [[Roman Empire|Roman]] source
- Governor of Bythinia
- Had a problem because Christians were gathering in his province
	- Passed a law that prevented gatherings, scared of political unrest


## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[Trajan]]
- [[Mentor, student, opponent, or contemporary]]

## My Notes
- < Reflections, controversies, connections to your studies >
