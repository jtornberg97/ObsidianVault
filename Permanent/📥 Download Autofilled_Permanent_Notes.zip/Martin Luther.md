---
title: Martin Luther
type: Person
birth_date: 1483 CE
death_date: 1546 CE
periods:
- Reformation
religious-tradition:
- Protestant
- Roman Catholic
- Lutheran
- Reformation
role:
- Theologian
- Reformer
- Priest
associated_movements:
- Reformation
notable_works:
- '[[95 Theses]]'
aliases:
- Luther
tags:
- Person
date_created: Wednesday, July 2nd 2025, 11:00:10 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: Martin Luther
---

# Martin Luther

## Summary
Martin Luther is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Contributions
- 
- 
- 

## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[John Calvin]]


## My Notes
- < Reflections, controversies, connections to your studies >
