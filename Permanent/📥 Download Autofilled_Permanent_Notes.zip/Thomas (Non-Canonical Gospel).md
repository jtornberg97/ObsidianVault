---
title: Thomas (Non-Canonical Gospel)
type: Biblical-Book
testament: '[[Gnostic]]'
author_tradition: null
date_written: null
cannonical_order: null
genre: null
audience: null
key_themes: null
related_books: null
tags:
- Bible
- Scripture
- Biblical-Book
date_created: Thursday, July 3rd 2025, 9:56:36 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
aliases:
- Thomas (Non-Canonical Gospel)
linter-yaml-title-alias: Thomas (Non-Canonical Gospel)
---

# Thomas (Non-Canonical Gospel)

## Summary

Collection of 114 sayings of [[Jesus|Jesus]]


## Audience & Context
< Who was the book written for and what was the historical setting? >

## Genre & Literary Features
- Genre:  
- Notable styles or structures:  

## Key Themes
- 
- 
- 

## Structure / Outline
1.  
2.  
3.  

## Theological Insights
< Important doctrinal or thematic contributions >


## My Notes
- < Observations, cross-references, interpretive notes >
