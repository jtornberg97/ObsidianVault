---
title: Joseph of Arimathea
type: Person
birth_date: 1st Century CE
death_date: 1st Century CE
periods:
- Second-Temple-Period
religious-tradition:
- Second-Temple-Judaism
role:
- Saint
associated_movements:
- Early Christianity
notable_works: null
aliases:
- Saint Joseph of Arimathea
tags:
- Second-Temple-Period
- Person
- Judaism/Second-Temple-Judaism
date_created: Thursday, July 3rd 2025, 8:58:59 pm
date_modified: Saturday, July 5th 2025, 12:51:26 am
linter-yaml-title-alias: Joseph of Arimathea
---

# Joseph of Arimathea

## Summary

## Key Contributions
- [[Bart Ehrman|Ehrman]] and Gospels say that he buried [[Jesus]] in his family tomb
- [[James Tabor]] says that it may have been out of [necessity](https://youtube.com/shorts/TV_KA8P9Dhg?si=mqZmqshpfTfgyNwj) rather than good will
- 

## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[Related person 1]]
- [[Mentor, student, opponent, or contemporary]]

## My Notes
- < Reflections, controversies, connections to your studies >
