---
title: Son of Man
type: Topic
periods:
- Second-Temple-Period
- Late-Second-Temple
religious-tradition:
- Ancient-Israelite-Religion
- Second-Temple-Judaism
tags:
- Topic
date_created: Tuesday, July 1st 2025, 10:38:21 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
aliases:
- Son of Man
linter-yaml-title-alias: Son of Man
---

# Son of Man

## Summary
Son of Man is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Points
- [[Bart Ehrman|Ehrman]]
	- [[Jesus|Jesus]] refers to the Son of Man as a sort of cosmic judge coming down from heaven, found in final book of the Hebrew Bible, [[Daniel]]
- 

## My Notes
- - Son of Man reflects a broader movement or idea in religious history.
- It shaped beliefs and practices over centuries.
- Modern interpretations vary widely.
- 