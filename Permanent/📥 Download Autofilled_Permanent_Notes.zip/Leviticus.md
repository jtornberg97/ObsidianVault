---
date_created: Tuesday, July 1st 2025, 11:20:52 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
title: Leviticus
aliases:
- Leviticus
tags:
- Topic
linter-yaml-title-alias: Leviticus
periods: null
religious-tradition: null
---
# Leviticus
