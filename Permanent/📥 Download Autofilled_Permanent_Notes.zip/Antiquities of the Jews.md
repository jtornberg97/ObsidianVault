---
title: Antiquities of the Jews
type: Primary-Source
author(s):
- '[[Josephus]]'
date_written: null
periods:
- Second-Temple-Period
- Late-Second-Temple
religious-tradition:
- Second-Temple-Judaism
source_type: Text
tags:
- Primary-Source
date_created: Wednesday, July 2nd 2025, 10:54:13 pm
date_modified: Sunday, July 6th 2025, 3:38:53 pm
aliases:
- Antiquities of the Jews
linter-yaml-title-alias: Antiquities of the Jews
---

# Antiquities of the Jews

## Source Overview
< Add a brief description of the source and its historical context >

## Key Themes or Passages
-  
-  
-  

## Text Context
<Information about where this text was written, its purpose, or audience >

## My Notes
- < Your detailed notes or excerpts go here >
