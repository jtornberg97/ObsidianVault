---
title: John the Baptist
type: Person
birth_date: null
death_date: null
periods:
- Second-Temple-Period
religious-tradition:
- '[[Apocalyptic Jews]]'
- Second-Temple-Judaism
role: Prophet
associated_movements:
- Early Christianity
- Apocalyptic-Judaism
notable_works: null
aliases:
- John the Baptizer
tags:
- Second-Temple-Period
- Person
- Apocalyptic
- Judaism/Second-Temple-Judaism
date_created: Wednesday, July 2nd 2025, 11:02:31 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: John the Baptist
---

# John the Baptist

## Summary
John the Baptist is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Contributions
- 
- 
- 

## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[Related person 1]]
- [[Mentor, student, opponent, or contemporary]]

## My Notes
- < Reflections, controversies, connections to your studies >
