---
title: NT Wright
type: Person
birth_date: "1948"
death_date: 
religious-tradition: 
role:
  - Biblical Scholar
  - Theologian
  - Bishop
  - Author
associated_movements:
  - "[[New Perspective on Paul]]"
  - "[[Anglican]]"
  - "[[Kingdom Theology]]"
  - "[[Resurrection Theology]]"
notable_works: 
tags:
  - Person
date_created: Tuesday, July 1st 2025, 8:08:01 pm
date_modified: Sunday, July 6th 2025, 9:39:20 pm
aliases:
  - NT Wright
  - N.T. Wright
  - Tom Wright
linter-yaml-title-alias: NT Wright
---

# NT Wright

## Summary
NT Wright is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Contributions
- 
- 
- 

## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[Related person 1]]
- [[Mentor, student, opponent, or contemporary]]

## My Notes
- < Reflections, controversies, connections to your studies >
