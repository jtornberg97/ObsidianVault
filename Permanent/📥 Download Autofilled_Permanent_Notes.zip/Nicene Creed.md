---
title: Nicene Creed
type: Topic
periods:
- Nicence-and-Post-Nicene
religious-tradition:
- Nicene Christianity
- Eastern Orthodox
- Protestant
tags:
- Topic
- Nicene-Christianity
- Protestant
- Eastern-Orthodox
- Nicene-and-Post-Nicene
date_created: Tuesday, July 1st 2025, 9:44:07 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
aliases:
- Nicene Creed
linter-yaml-title-alias: Nicene Creed
---

# Nicene Creed

## Summary
Made at the [[Council of Nicaea]]

## Key Points
- 
- 
- 

## My Notes
- < Key takeaways, reflections, or disagreements >
- 