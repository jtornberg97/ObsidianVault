---
title: Genesis
type: Biblical-Book
testament: null
author_tradition: null
date_written: null
cannonical_order: null
genre: null
audience: null
key_themes: null
related_books: null
aliases:
- '# Genesis'
tags:
- Bible
- Scripture
- Biblical-Book
linter-yaml-title-alias: Genesis
date_created: Tuesday, July 1st 2025, 11:20:46 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
---

# # Genesis

## Summary
< Brief overview of the book’s content and purpose >

## Audience & Context
< Who was the book written for and what was the historical setting? >

## Genre & Literary Features
- Genre:  
- Notable styles or structures:  

## Key Themes
- 
- 
- 

## Structure / Outline
1.  
2.  
3.  

## Theological Insights
< Important doctrinal or thematic contributions >


## My Notes
- < Observations, cross-references, interpretive notes >
