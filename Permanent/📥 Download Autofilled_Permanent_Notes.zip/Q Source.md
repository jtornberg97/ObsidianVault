---
title: Q Source
type: Topic
periods: null
religious-tradition: null
aliases:
- Q
tags:
- Topic
date_created: Tuesday, July 1st 2025, 10:51:30 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
linter-yaml-title-alias: Q Source
---

# Q Source

## Summary
< Add a brief overview of the toipc >

## Key Points
- [[Bart Ehrman|Ehrman]] - "A Gospel source available to [[Matthew (Gospel)]] and [[Luke (Gospel)]], now lost" --> [[Synoptic Problem]]
- 

## My Notes
- - Q Source reflects a broader movement or idea in religious history.
- It shaped beliefs and practices over centuries.
- Modern interpretations vary widely.
- 