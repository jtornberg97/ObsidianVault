---
title: James Tabor
type: Person
birth_date: '1946'
death_date: null
periods:
- Modern-Period
religious-tradition:
- Scholar
role: Biblical Scholar
associated_movements: Historical Jesus
notable_works:
- https://youtube.com/shorts/TV_KA8P9Dhg?si=mqZmqshpfTfgyNwj
aliases:
- James D. Tabor
- James D Tabor
tags:
- Person
- Modern-Period
- Scholar
date_created: Friday, July 4th 2025, 9:38:57 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: James Tabor
---

# James Tabor

## Summary
James Tabor is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Contributions
- 
- 
- 

## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[Related person 1]]
- [[Mentor, student, opponent, or contemporary]]

## My Notes
- < Reflections, controversies, connections to your studies >
