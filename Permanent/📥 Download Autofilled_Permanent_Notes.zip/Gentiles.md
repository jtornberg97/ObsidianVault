---
title: Gentiles
type: Topic
periods:
- Ongoing
religious-tradition:
- Secular
tags:
- Topic
date_created: Tuesday, July 1st 2025, 8:41:09 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
aliases:
- Gentiles
linter-yaml-title-alias: Gentiles
---

# Gentiles

## Summary
Non-Jews

## Key Points
- 
- 
- 

## My Notes
- < Key takeaways, reflections, or disagreements >
