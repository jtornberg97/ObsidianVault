---
title: 95 Theses
type: Topic
periods:
- Reformation
religious-tradition:
- Lutheran
- Roman Catholic
aliases:
- Luther's 95 Theses
tags:
- Lutheran
- Topic
- Reformation
- Roman-Catholic
author(s):
- '[[John Calvin]]'
date_created: Tuesday, July 1st 2025, 10:56:29 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: 95 Theses
---

# 95 Theses

## Summary
95 Theses is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Points
- 
- 
- 

## My Notes
- - 95 Theses reflects a broader movement or idea in religious history.
- It shaped beliefs and practices over centuries.
- Modern interpretations vary widely.
- 