---
title: Sadducees
type: Topic
periods:
- Second-Temple-Period
religious-tradition:
- Second-Temple-Judaism
aliases:
- Saduccee
tags:
- Second-Temple-Period
- Topic
- Judaism/Second-Temple-Judaism
date_created: Tuesday, July 1st 2025, 10:39:05 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
linter-yaml-title-alias: Sadducees
---

# Sadducees

## Summary
- High priests during the [[Second Temple Period]], Jesus directed criticism to them

## Key Points
- 
- 
- 

## My Notes
- < Key takeaways, reflections, or disagreements >
- 