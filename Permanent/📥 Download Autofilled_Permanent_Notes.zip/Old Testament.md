---
date_created: Thursday, July 3rd 2025, 9:34:00 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
title: Old Testament
aliases:
- Old Testament
tags:
- Topic
linter-yaml-title-alias: Old Testament
periods: null
religious-tradition: null
---
# Old Testament
