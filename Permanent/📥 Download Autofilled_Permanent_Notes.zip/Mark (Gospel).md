---
title: Mark (Gospel)
type: Biblical-Book
testament: null
author_tradition: null
date_written: null
cannonical_order: null
genre: null
audience: null
key_themes: null
related_books:
- '[[Matthew (Gospel)]]'
- '[[Luke (Gospel)]]'
tags:
- Bible
- Scripture
- Biblical-Book
date_created: Tuesday, July 1st 2025, 10:36:57 pm
date_modified: Monday, July 7th 2025, 9:38:26 pm
aliases:
- Mark (Gospel)
linter-yaml-title-alias: Mark (Gospel)
---

# Mark (Gospel)

## Summary

First of the [[Synoptic Problem|Synoptic Gospels]], likely the first [[Gospels]]

## Audience & Context
< Who was the book written for and what was the historical setting? >

## Genre & Literary Features
- Genre:  
- Notable styles or structures:  

## Key Themes
- 
- 
- 

## Structure / Outline
1.  [[Mark Chapter 1]]
2.  
3.  

## Theological Insights
< Important doctrinal or thematic contributions >


## My Notes
- < Observations, cross-references, interpretive notes >
