---
title: King David
type: Person
birth_date: ~1040 BCE
death_date: ~970 BCE
periods:
- United-Monarchy
religious-tradition:
- Ancient-Israelite-Religion
role: King of Israel
associated_movements: Davidic Dynasty
notable_works: null
tags:
- United-Monarchy
- Person
- Judaism/Ancient-Israelite-Religion
date_created: Thursday, July 3rd 2025, 9:26:09 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
aliases:
- King David
linter-yaml-title-alias: King David
---

# King David

## Summary
King David is a significant topic in historical theology, often discussed for its impact on religious development, doctrinal interpretation, and socio-political influence.

## Key Contributions
- 
- 
- 

## Historical Context
< Time period, major events, and religious/political setting >

## Notable Works
- *Title*, Year – Summary
- [[Link to primary or secondary sources]]


## Related Figures
- [[Related person 1]]
- [[Mentor, student, opponent, or contemporary]]

## My Notes
- < Reflections, controversies, connections to your studies >
