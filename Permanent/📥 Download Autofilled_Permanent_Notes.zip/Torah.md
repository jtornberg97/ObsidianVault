---
title: Torah
type: Primary-Source
author(s): null
date_written: null
periods: null
religious-tradition: null
source_type: Text
tags:
- Primary-Source
date_created: Tuesday, July 1st 2025, 10:32:34 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
aliases:
- Torah
linter-yaml-title-alias: Torah
---

# Torah

## Source Overview
- Laws given to the Jewish people
- First 5 books of the Bible ([[Genesis]], [[Exodus]], [[Leviticus]], [[Numbers]], [[Deuteronomy]])

## Key Themes or Passages
-  
-  
-  

## Text Context
<Information about where this text was written, its purpose, or audience >

## My Notes
- < Your detailed notes or excerpts go here >
