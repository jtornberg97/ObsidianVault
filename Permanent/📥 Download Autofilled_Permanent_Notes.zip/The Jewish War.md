---
title: The Jewish War
type: Primary-Source
author(s):
- '[[Josephus]]'
date_written: null
periods:
- Second-Temple-Period
religious-tradition:
- Second-Temple-Judaism
source_type: Text
tags:
- Primary-Source
- Judaism/Second-Temple-Judaism
date_created: Wednesday, July 2nd 2025, 10:48:28 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
aliases:
- The Jewish War
linter-yaml-title-alias: The Jewish War
---

# The Jewish War

## Source Overview
< Add a brief description of the source and its historical context >

## Key Themes or Passages
-  
-  
-  

## Text Context
<Information about where this text was written, its purpose, or audience >

## My Notes
- < Your detailed notes or excerpts go here >
