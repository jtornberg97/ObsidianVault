---
title: Heresy
type: Topic
periods:
- Ongoing
religious-tradition: null
tags:
- Topic
- Ongoing
date_created: Tuesday, July 1st 2025, 10:31:41 pm
date_modified: Friday, July 4th 2025, 11:43:44 pm
aliases:
- Heresy
linter-yaml-title-alias: Heresy
---

# Heresy

## Summary
- "Choice" - Greek

## Key Points
- 
- 
- 

## My Notes
- < Key takeaways, reflections, or disagreements >
- 