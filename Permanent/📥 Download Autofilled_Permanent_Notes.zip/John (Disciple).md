---
date_created: Tuesday, July 1st 2025, 10:36:19 pm
date_modified: Friday, July 4th 2025, 11:42:23 pm
title: John (Disciple)
aliases:
- John (Disciple)
tags:
- Topic
linter-yaml-title-alias: John (Disciple)
periods: null
religious-tradition: null
---
# John (Disciple)
